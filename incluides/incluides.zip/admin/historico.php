<?php 
  include_once "../header/header.php"; 
  require("../base_datos/conexion/conexion.php");
?>

<?php
    include_once "../header/header2.php"; 
?>